import type {
    Chapter,
    GetFilterConfig,
    GetLatestSeries,
    GetMangaChapterDetails,
    GetMangaChapters,
    GetPopularSeries,
    GetSeries,
    Manga,
    SearchSeries,
    SeriesListResponse,
    Server,
    ServerSupportExtension,
} from "@tsukimichi-extensions/common";
import * as cheerio from "cheerio";

import { BaseMangaScraper } from "@/generic/base-manga-scraper";
import manifest from "./manifest.json";

export class ManhwasMen extends BaseMangaScraper {
    override requireCoverImageProxy = true;

    #headers = {
        "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36",
        Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    };

    constructor() {
        super(manifest);
    }

    override supportsLatest = false;

    override searchSeries: SearchSeries<Manga> = async (query, options) => {
        const { page = 1 } = options?.searchOptions ?? {};
        const pageNumStr = Math.max(page, 1).toString();
        const url = new URL("manga-list", this.baseUrl);
        url.searchParams.set("search", query);
        url.searchParams.set("page", pageNumStr);

        const html = await this.fetchHtml(url.toString(), {
            init: {
                headers: this.#headers,
            },
        });

        return this.#parseSearchResult(html);
    };

    override getSeries: GetSeries<Manga> = async (query) => {
        const url = new URL(query, this.baseUrl);
        const html = await this.fetchHtml(url.toString(), {
            init: {
                headers: this.#headers,
            },
        });
        const $ = cheerio.load(html);

        const $seriesContainer = $("article .container .row").first();
        if (!$seriesContainer.length) return null;

        const title = $seriesContainer.find("h1.title").text().trim();
        const alternateTitles = $seriesContainer
            .find(".h5")
            .text()
            .split(",")
            .filter(Boolean);
        const statusText = $seriesContainer
            .find(".meta .anime-type-peli:nth-of-type(2)")
            .text();
        const coverImageUrl =
            $seriesContainer.find(".thumb img").attr("src") || null;
        const genres = $seriesContainer
            .find(".genres a")
            .get()
            .map((el) => $(el).text().trim())
            .filter(Boolean);
        const description = $seriesContainer.find(".sinopsis").text().trim();

        const $latestChapterEl = $("ul.episodes-list li:first-of-type a");

        const lastUpdatedText = $latestChapterEl
            .find("p span")
            .parent()
            .next("span")
            .text()
            .trim();

        return {
            id: `series-${this.slugify(title)}`,
            extensionId: this.extensionMetadata.id,
            source: this.name,
            title,
            alternateTitles,
            status: this.getSeriesStatus(statusText),
            coverImageUrl,
            genres,
            description,
            url: this.getUrlPath(url.toString()),
            isNsfw:
                genres?.length > 0
                    ? this.detectNsfw(title, description, genres)
                    : null,
            isLocal: false,
            lastUpdated: this.parseSeriesDate(lastUpdatedText),
        };
    };

    override getChapters: GetMangaChapters = async (query) => {
        const url = new URL(query, this.baseUrl);
        const html = await this.fetchHtml(url.toString(), {
            init: {
                headers: this.#headers,
            },
        });
        const $ = cheerio.load(html);

        const chapters: Chapter[] = [];

        $(".episodes-list li a").each((_, el) => {
            const $el = $(el);
            const title = $el.find("p span").text().trim();
            const url = this.getUrlPath($el.attr("href") || "");
            const chapterNumber = this.getLargestNumber([title]);
            const lastUpdatedText = $el
                .find("p span")
                .parent()
                .next("span")
                .text()
                .trim();
            const lastUpdated = this.parseSeriesDate(lastUpdatedText);

            chapters.push({
                id: `chapter-${this.slugify(title)}`,
                extensionId: this.extensionMetadata.id,
                source: this.name,
                url,
                imageUrls: [],
                totalPages: 0,
                languageKey: "en",
                title,
                chapterNumber: chapterNumber?.toString(),
                lastUpdated,
                groupName: null,
                volumeNumber: null,
            });
        });

        return this.addChapterNavigation(chapters?.reverse()) || [];
    };

    override getChapter: GetMangaChapterDetails = async (query) => {
        const url = new URL(query, this.baseUrl);
        const serverUrl = url.searchParams.get("sv");

        const serverPreferences = this.serverSupport?.getServerPreferences(
            serverUrl || "",
        );
        const currentServer = serverPreferences?.currentServer?.value;

        const html = await this.fetchHtml(url.toString(), {
            init: {
                headers: this.#headers,
            },
        });
        const $ = cheerio.load(html);

        const serversObj: Record<string, string> = {};

        $("script").each((_, scriptEl) => {
            const scriptContent = $(scriptEl).html();
            if (scriptContent?.includes("servers = {")) {
                const match = scriptContent.match(
                    /servers\s*=\s*({[\s\S]*?})\s*;/,
                );
                if (match) {
                    try {
                        const parsed = new Function(`return ${match[1]}`)();
                        Object.assign(serversObj, parsed);
                    } catch (err) {
                        console.error(
                            "Failed to parse servers object:",
                            (err as Error).message,
                        );
                    }
                }
            }
        });

        const imageUrls: string[] = [];

        const entries = Object.entries(serversObj);

        if (entries.length > 0) {
            if (currentServer?.trim()) {
                const found = entries.find(
                    ([key]) => key.toLowerCase() === currentServer,
                );
                if (found) {
                    const [_, value] = found;

                    const $$ = cheerio.load(value);
                    $$("img").each((_, el) => {
                        const src = $$(el).attr("src");
                        if (src) imageUrls.push(src);
                    });
                }
            } else {
                // @ts-expect-error
                const [_, value] = entries[0];
                const $$ = cheerio.load(value);
                $$("img").each((_, el) => {
                    const src = $$(el).attr("src");
                    if (src) imageUrls.push(src);
                });
            }
        } else {
            $("#chapter_imgs img").each((_, el) => {
                const src = $(el).attr("src");
                if (src) imageUrls.push(src);
            });
        }

        if (imageUrls.length === 0) return null;

        const titleText = $("h1.anime-title").text().trim();
        const title = titleText?.match(/\bChapter\s+\d+\b/i)?.[0] || titleText;

        const nextChapterUrl =
            $('.episodes-nav a:contains("Next")').attr("href") || null;
        const previousChapterUrl =
            $('.episodes-nav a:contains("Prev")').attr("href") || null;
        const nextChapter = nextChapterUrl
            ? `${this.getUrlPath(nextChapterUrl)}?sv=${currentServer}`
            : null;
        const previousChapter = previousChapterUrl
            ? `${this.getUrlPath(previousChapterUrl)}?sv=${currentServer}`
            : null;

        return {
            id: `single-chapter-${this.slugify(title)}`,
            extensionId: this.extensionMetadata.id,
            source: this.name,
            title,
            imageUrls,
            totalPages: imageUrls.length,
            languageKey: "en",
            chapterNumber: this.getLargestNumber([title])?.toString(),
            groupName: null,
            lastUpdated: null,
            volumeNumber: null,
            url: `${url.pathname}?sv=${currentServer}`,
            nextChapter,
            previousChapter,
        };
    };

    override getPopularSeries: GetPopularSeries<Manga> = async (options) => {
        const { page = 1 } = options?.searchOptions ?? {};
        const pageNumStr = Math.max(page, 1).toString();
        const url = new URL("manga-list", this.baseUrl);
        url.searchParams.set("page", pageNumStr);

        const html = await this.fetchHtml(url.toString(), {
            init: {
                headers: this.#headers,
            },
        });
        return this.#parseSearchResult(html);
    };

    override getLatestSeries: GetLatestSeries<Manga> = async () => {
        throw new Error("METHOD_NOT_IMPLEMENTED");
    };

    override getFilterConfig: GetFilterConfig = () => ({
        extensionId: this.extensionMetadata.id,
        extensionName: this.extensionMetadata.name,
        supportedFilters: [],
    });

    override serverSupport?: ServerSupportExtension | undefined = {
        supportsMultipleServers: true,
        getAvailableServers: () => this.#availableServers,
        getServerPreferences: (currentServerValue) => {
            return this.createServerPreferences(
                this.#availableServers,
                currentServerValue,
            );
        },
        validateServer: (server) => {
            return this.#availableServers.some((s) => s.value === server);
        },
    };

    #availableServers: Server[] = [
        {
            name: "Alpha",
            value: "alpha",
            isDefault: true,
        },
        {
            name: "Beta",
            value: "beta",
            isDefault: false,
        },
        {
            name: "Gamma",
            value: "gamma",
            isDefault: false,
        },
    ];

    #parseSearchResult(html: string): SeriesListResponse<Manga> {
        const $ = cheerio.load(html);

        const mangaList: Manga[] = [];

        $("ul.animes li.col-6").each((_, el) => {
            const $el = $(el).find("article");

            const $anchor = $el.find("a");
            const coverImageUrl = $el.find("img").attr("src") || null;
            const title = $el.find("h3.title").text().trim();

            mangaList.push({
                id: `series-${this.slugify(title)}`,
                extensionId: this.extensionMetadata.id,
                source: this.name,
                title,
                coverImageUrl,
                isNsfw: null,
                status: "unknown",
                url: this.getUrlPath($anchor.attr("href") || ""),
            });
        });

        const nextPage = this.getLargestNumber([
            $('ul.pagination li a[rel="next"]').attr("href") || "",
        ]);

        const currentPage =
            this.getLargestNumber([
                $("ul.pagination li.active .page-link").text() || "1",
            ]) || 1;

        const hasMore = nextPage ? nextPage > currentPage : false;

        return {
            data: mangaList,
            pagination: {
                hasMore,
                nextPage: hasMore ? nextPage : null,
            },
        };
    }
}
