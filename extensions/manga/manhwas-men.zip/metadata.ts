import type { ExtensionMetadata } from "@tsukimichi-extensions/common";

export const METADATA: ExtensionMetadata = {
    id: "8cee4a0f-78e4-4a30-8321-bd9c6244901a",
    name: "Manhwas.Men",
    description: "",
    isManga: true,
    containsNSFWContent: true,
    isNSFWFocused: true,
    minAppVersion: "1.0.0",
    url: "https://manhwas.men",
    iconUrl:
        "https://t0.gstatic.com/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&url=https://manhwas.men&size=128",
    version: "",
    apiUrl: "",
};
