import type { ExtensionMetadata } from "@tsukimichi-extensions/common";

export const METADATA: ExtensionMetadata = {
    id: "e0c0fe56-2609-4425-b023-bf9057166631",
    name: "ManhuaGold",
    description: "",
    iconUrl:
        "https://t0.gstatic.com/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&url=https://manhuagold.top&size=128",
    isManga: true,
    containsNSFWContent: true,
    isNSFWFocused: false,
    minAppVersion: "1.0.0",
    url: "https://manhuagold.top",
    version: "",
    apiUrl: "",
};
