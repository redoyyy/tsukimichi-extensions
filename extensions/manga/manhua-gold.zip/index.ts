import type {
    Chapter,
    GetFilterConfig,
    GetLatestSeries,
    GetMangaChapterDetails,
    GetMangaChapters,
    GetPopularSeries,
    GetSeries,
    Manga,
    SearchSeries,
} from "@tsukimichi-extensions/common";
import * as cheerio from "cheerio";

import { BaseMangaScraper } from "@/generic/base-manga-scraper";
import manifest from "./manifest.json";

export class ManhuaGold extends BaseMangaScraper {
    override requireCoverImageProxy = false;
    override requireChapterImageProxy = false;

    constructor() {
        super(manifest);
    }

    // TODO: add advanced search filters
    override searchSeries: SearchSeries<Manga> = async (query) => {
        const formBody = new URLSearchParams();
        formBody.set("search", query);

        const formHeaders = (() => {
            const headers = this.headersBuilders();
            headers.append(
                "Accept",
                "application/json, text/javascript, */*; q=0.01",
            );
            headers.append("Host", new URL(this.baseUrl).host);
            headers.append("Origin", this.baseUrl);
            headers.append(
                "Content-Type",
                "application/x-www-form-urlencoded; charset=UTF-8",
            );
            headers.append("X-Requested-With", "XMLHttpRequest");
            headers.delete("Referer");
            return headers;
        })();

        const response = await fetch(`${this.baseUrl}/ajax/search`, {
            method: "POST",
            headers: formHeaders,
            body: formBody.toString(),
        });

        const json = await response.json();

        const list = json?.list || [];

        if (!list?.length) {
            return {
                data: [],
            };
        }

        const data: Manga[] = list.map((item: any) => ({
            id: this.slugify(item.name),
            extensionId: this.extensionMetadata.id,
            title: item.name,
            url: this.#getUrlPath(item.url),
            genres: item?.genres?.split(",")?.filter(Boolean) || [],
            lastUpdated: this.parseSeriesDate(item.update),
            status: "unknown",
            coverImageUrl: `${this.baseUrl}${item.cover}`,
        }));

        return {
            data,
            pagination: {
                hasMore: false,
                nextPage: null,
            },
        };
    };

    override getSeries: GetSeries<Manga> = async (query) => {
        const pageUrl = new URL(query, this.baseUrl);
        const html = await this.fetchHtml(pageUrl.toString(), {
            init: { headers: this.headersBuilders() },
        });
        const $ = cheerio.load(html);

        const title = $("header h1").first().text().trim();
        const alternateTitles =
            $("header p")
                .text()
                ?.trim()
                ?.replace("Other name:", "")
                ?.split("; ")
                ?.filter(Boolean) || [];

        const genres = $("article")
            .parent()
            .find("a.label")
            .get()
            .map((el) => $(el).text().trim())
            .filter(Boolean);

        const description = $("article div#syn-target").first().text()?.trim();

        const coverImagePath = $("figure > a > img").attr("src");
        const coverImageUrl = coverImagePath
            ? new URL(coverImagePath, this.baseUrl).toString()
            : null;

        const hasAgeWarning =
            $('.boxs.error b:contains("Age warning")').length > 0;

        const rawRating = Number.parseFloat(
            $('span#ratingScore[itemprop="ratingValue"]').text()?.trim() || "",
        );
        const rating = Number.isNaN(rawRating) ? null : rawRating;
        const authors = $("#extra-info .dt a")
            .get()
            .map((el) => $(el).text())
            .filter(Boolean);
        const status = this.getSeriesStatus(
            $('.y6x11p:contains("Status") .dt').text().trim(),
        );
        const lastUpdated = this.parseSeriesDate(
            $('.y6x11p:contains("Update") .dt').text().trim(),
        );

        const url = $('meta[property="og:url"]').attr("content") || "";

        return {
            id: this.slugify(title),
            extensionId: this.extensionMetadata.id,
            title,
            alternateTitles,
            description,
            coverImageUrl,
            status,
            rating,
            genres,
            isNsfw:
                hasAgeWarning ||
                this.detectNsfw(title, description, genres, alternateTitles),
            source: this.name,
            url: this.#getUrlPath(url),
            authors,
            lastUpdated,
            isLocal: false,
        };
    };

    override getLatestSeries: GetLatestSeries<Manga> = async (options) => {
        const { page = 1 } = options?.searchOptions ?? {};
        const url = new URL(`/all-manga/${page}`, this.baseUrl);
        url.searchParams.set("sort", "last_update");
        url.searchParams.set("status", "0");

        const html = await this.fetchHtml(url.toString(), {
            init: { headers: this.headersBuilders() },
        });

        return this.#parseSearchFromListing(html);
    };

    override getPopularSeries: GetPopularSeries<Manga> = async (options) => {
        const { page = 1 } = options?.searchOptions ?? {};
        const url = new URL(`/all-manga/${page}`, this.baseUrl);
        url.searchParams.set("sort", "views");
        url.searchParams.set("status", "0");

        const html = await this.fetchHtml(url.toString(), {
            init: { headers: this.headersBuilders() },
        });

        return this.#parseSearchFromListing(html);
    };

    override getChapter: GetMangaChapterDetails = async (query) => {
        const pageUrl = new URL(query, this.baseUrl);
        const pageHtml = await this.fetchHtml(pageUrl.toString(), {
            init: { headers: this.headersBuilders() },
        });

        const $ = cheerio.load(pageHtml);

        const script = $('script:contains("const CHAPTER_ID =")')
            .first()
            .text();
        if (!script) throw new Error("Script containing CHAPTER_ID not found");

        const chapterId = script.match(
            /const\s+CHAPTER_ID\s*=\s*(\d+)\s*;/,
        )?.[1];
        if (!chapterId)
            throw new Error("CHAPTER_ID not found in script content");

        const title = $("#main h1").first().text().trim();
        const url = $('meta[property="og:url"]').attr("content");

        const pageHeaders = (() => {
            const headers = this.headersBuilders();
            headers.append(
                "Accept",
                "application/json, text/javascript, */*; q=0.01",
            );
            headers.append("Host", pageUrl.host);
            headers.append("X-Requested-With", "XMLHttpRequest");
            return headers;
        })();

        const response = await this.fetchWithRetry(
            `${this.baseUrl}/ajax/image/list/chap/${chapterId}`,
            3,
            { init: { method: "POST", headers: pageHeaders } },
        );

        const data = await response.json();
        if (!data?.status) throw new Error(data?.message);

        const html = data?.html;
        const $chapter = cheerio.load(html);

        const imageUrls = $chapter("img")
            .get()
            .map((el) => $chapter(el).attr("src")?.trim())
            .filter(Boolean) as string[];

        const chapters = await this.getChapters(
            query.split("/").slice(0, -1).join("/"),
        );
        const currentPath = this.#getUrlPath(url || query);
        const index = chapters.findIndex((ch) => ch.url === currentPath);

        const previousChapter = index > 0 ? chapters[index - 1]?.url : null;
        const nextChapter =
            index < chapters.length - 1 ? chapters[index + 1]?.url : null;

        return {
            id: this.slugify(title),
            extensionId: this.extensionMetadata.id,
            title,
            imageUrls,
            source: this.name,
            url: currentPath,
            previousChapter,
            nextChapter,
            read: false,
            totalPages: imageUrls.length,
            languageKey: "en",
        };
    };

    override getChapters: GetMangaChapters = async (query) => {
        const url = new URL(query, this.baseUrl);
        const html = await this.fetchHtml(url.toString(), {
            init: { headers: this.headersBuilders() },
        });
        const $ = cheerio.load(html);

        const chapters: Chapter[] = [];

        $("ul#myUL li").each((_, el) => {
            const $el = $(el);
            const $anchor = $el.find("a");
            const url = $anchor.attr("href");
            const titleFromEl = $anchor.text()?.trim();
            const chapterNumber = this.extractChapterNumber(titleFromEl);
            const lastUpdated = this.parseSeriesDate(
                $el.find("time").text()?.trim(),
            );

            chapters.push({
                id: this.slugify(titleFromEl),
                extensionId: this.extensionMetadata.id,
                title: chapterNumber ? `Chapter ${chapterNumber}` : titleFromEl,
                source: this.name,
                url: this.#getUrlPath(url || ""),
                imageUrls: [],
                totalPages: 0,
                lastUpdated,
                languageKey: "en",
                chapterNumber,
            });
        });

        return this.addChapterNavigation(chapters?.reverse()) || [];
    };

    #parseSearchFromListing(html: string, isGenre = false) {
        const $ = cheerio.load(html);

        const data: Manga[] = $("#Blog1 section .grid div:first-child")
            .get()
            .map((el) => {
                const $el = $(el);
                const $anchor = $el.find("a").first();
                const $img = $anchor.find("img");
                const coverImagePath = $img.attr("data-src");
                const coverImageUrl = coverImagePath
                    ? new URL(coverImagePath, this.baseUrl).toString()
                    : null;

                const url = this.#getUrlPath($anchor.attr("href") || "");

                const title =
                    $anchor.attr("title")?.trim() ||
                    $img.attr("alt")?.trim() ||
                    $img.attr("title")?.trim() ||
                    "";
                ("");

                return {
                    id: this.slugify(title),
                    extensionId: this.extensionMetadata.id,
                    title,
                    url,
                    coverImageUrl,
                    isNsfw: null,
                    source: this.name,
                    status: "unknown" as Manga["status"],
                };
            })
            .filter((manga) => manga.url && manga.url !== "/");

        const lastPageHref =
            $("#blog-pager")
                .find(
                    isGenre ? "a[href*='/genres/']" : "a[href*='/all-manga/']",
                )
                .last()
                .attr("href") || "";

        const lastPage = lastPageHref
            ? Number.parseInt(
                  lastPageHref.match(
                      isGenre
                          ? /\/genres\/[^/]+\/(\d+)\//
                          : /\/all-manga\/(\d+)\//,
                  )?.[1] || "",
              )
            : 1;

        const currentPage = Number.parseInt(
            $("#blog-pager .pagecurrent").text().trim() || "1",
            10,
        );
        const hasMore = currentPage < lastPage;
        const nextPage = hasMore ? currentPage + 1 : null;

        return {
            data,
            pagination: {
                hasMore,
                nextPage,
            },
        };
    }

    // TODO: add filters
    override getFilterConfig: GetFilterConfig = () => {
        return {
            extensionId: this.extensionMetadata.id,
            extensionName: this.name,
            supportedFilters: [],
        };
    };

    #getUrlPath(url: string) {
        const parsedUrl = new URL(url, this.baseUrl);
        return parsedUrl.pathname;
    }
}
