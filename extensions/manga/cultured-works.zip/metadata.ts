import type { ExtensionMetadata } from "@tsukimichi-extensions/common";

export const METADATA: ExtensionMetadata = {
    id: "c85ec5d0-eb47-44ae-8b69-f4925f739a00",
    name: "CulturedWorks",
    description: "",
    isManga: true,
    containsNSFWContent: true,
    isNSFWFocused: false,
    minAppVersion: "1.0.0",
    url: "https://culturedworks.com",
    iconUrl:
        "https://t0.gstatic.com/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&url=https://culturedworks.com&size=128",
    version: "",
    apiUrl: "",
};
