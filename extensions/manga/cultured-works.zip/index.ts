import { MangaReader } from "@/lib/multi-src/manga-reader";

import manifest from "./manifest.json";
export class CulturedWorks extends MangaReader {
    override requireCoverImageProxy = false;

    constructor() {
        super(manifest);
    }
}
