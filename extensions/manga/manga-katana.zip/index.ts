import type {
    Chapter,
    GetFilterConfig,
    GetLatestSeries,
    GetMangaChapterDetails,
    GetMangaChapters,
    GetPopularSeries,
    GetSeries,
    Manga,
    SearchSeries,
    SeriesListResponse,
    Server,
    ServerSupportExtension,
} from "@tsukimichi-extensions/common";
import * as cheerio from "cheerio";

import { BaseMangaScraper } from "@/generic/base-manga-scraper";

import manifest from "./manifest.json";

export class MangaKatana extends BaseMangaScraper {
    override supportsPopular = false;
    override requireCoverImageProxy = false;
    override requireChapterImageProxy = false;

    constructor() {
        super(manifest);
    }

    override searchSeries: SearchSeries<Manga> = async (query, options) => {
        const { page = 1 } = options?.searchOptions ?? {};
        const pageNum = Math.max(page, 1);

        const url = new URL(`page/${pageNum}`, this.baseUrl);
        url.searchParams.set("search", query);
        url.searchParams.set("search_by", "book_name");

        const html = await this.fetchHtml(url.toString());

        const result = this.#parseSearchResult(html);
        if (result?.data?.length > 0) return result;

        // When there's only one search result, MangaKatana sometimes redirects
        // directly to the manga details page instead of showing a search results page.
        // In this case, we parse the manga details and return it as a single result.
        const newResult = this.#parseManga(html);
        return {
            data: newResult ? [newResult] : [],
            pagination: {
                hasMore: false,
                nextPage: null,
            },
        };
    };

    override getSeries: GetSeries<Manga> = async (query) => {
        const url = new URL(query, this.baseUrl);

        const html = await this.fetchHtml(url.toString());
        return this.#parseManga(html);
    };

    override getChapters: GetMangaChapters = async (query) => {
        const url = new URL(query, this.baseUrl);

        const html = await this.fetchHtml(url.toString());

        const chapters: Chapter[] = [];

        const $ = cheerio.load(html);

        const $chapter = $("table tbody tr");

        if (!$chapter.length) return [];

        $chapter.each((_, el) => {
            const $el = $(el);
            const titleFromEl = $el.find("a").text();
            const chapterNumber = this.extractChapterNumber(titleFromEl);
            const url = $el.find("a").attr("href") || "";
            const lastUpdated = this.parseSeriesDate(
                $el.find("td .update_time").text(),
            );

            chapters.push({
                id: `chapter-${this.slugify(titleFromEl)}`,
                extensionId: this.extensionMetadata.id,
                title: chapterNumber ? `Chapter ${chapterNumber}` : titleFromEl,
                url,
                source: this.name,
                lastUpdated,
                imageUrls: [],
                languageKey: "en",
                totalPages: 0,
                groupName: null,
                volumeNumber: null,
                chapterNumber,
            });
        });

        return this.addChapterNavigation(chapters?.reverse()) || [];
    };

    override getChapter: GetMangaChapterDetails = async (query) => {
        const url = new URL(query, this.baseUrl);

        const serverUrl = url.searchParams.get("sv");
        const currentServer = this.serverSupport?.getServerPreferences(
            serverUrl || "",
        )?.currentServer.value;

        const html = await this.fetchHtml(url.toString());

        const $ = cheerio.load(html);

        const imageUrls: string[] = [];

        const title = $('ol[typeof="BreadcrumbList"] li:last-of-type span')
            .first()
            .text();

        const previousChapter = $(".nav_button.prev").attr("href");
        const nextChapter = $(".nav_button.next").attr("href");

        if (imageUrls.length === 0) {
            const scriptContent = html;

            // Look for common manga reader array variable names
            const commonArrayNames = [
                "thzq",
                "ytaw",
                "images",
                "pages",
                "imageUrls",
            ];

            for (const arrayName of commonArrayNames) {
                const regex = new RegExp(
                    `var\\s+${arrayName}\\s*=\\s*\\[([^\\]]+)\\]`,
                    "i",
                );
                const match = scriptContent.match(regex);

                if (match) {
                    const arrayContent = match[1];
                    const urlMatches = arrayContent?.match(/'([^']+)'/g) || [];

                    for (const urlMatch of urlMatches) {
                        const imageUrl = urlMatch.replace(/'/g, "");
                        if (
                            imageUrl.includes(".jpg") ||
                            imageUrl.includes(".jpeg") ||
                            imageUrl.includes(".png") ||
                            imageUrl.includes(".gif")
                        ) {
                            imageUrls.push(imageUrl);
                        }
                    }

                    if (imageUrls.length > 0) {
                        break;
                    }
                }
            }
        }

        const chapter: Chapter = {
            id: `single-chapter-${this.slugify(title)}`,
            extensionId: this.extensionMetadata.id,
            title,
            url: this.getUrlPath(url.toString()),
            imageUrls,
            source: this.name,
            languageKey: "en",
            totalPages: imageUrls.length,
            groupName: null,
            volumeNumber: null,
            chapterNumber: null,
            previousChapter: !previousChapter?.includes("javascript:")
                ? `${previousChapter}${currentServer ? `?sv=${currentServer}` : ""}`
                : null,
            nextChapter: !nextChapter?.includes("javascript:")
                ? `${nextChapter}${currentServer ? `?sv=${currentServer}` : ""}`
                : null,
        };

        return chapter;
    };

    override getLatestSeries: GetLatestSeries<Manga> = async (options) => {
        const { page = 1 } = options?.searchOptions ?? {};
        const pageNum = Math.max(page, 1);
        const url = new URL(`manga/page/${pageNum}`, this.baseUrl);
        url.searchParams.set("filter", "1");
        url.searchParams.set("order", "latest");

        const html = await this.fetchHtml(url.toString());

        return this.#parseSearchResult(html);
    };

    override getPopularSeries: GetPopularSeries<Manga> = async () => {
        throw new Error("METHOD_NOT_IMPLEMENTED");
    };

    #availableServers: Server[] = [
        {
            name: "Server 1",
            value: "",
            isDefault: true,
        },
        {
            name: "Server 2",
            value: "mk",
        },
        {
            name: "Server 3",
            value: "3",
        },
    ];

    override serverSupport?: ServerSupportExtension | undefined = {
        supportsMultipleServers: true,

        getAvailableServers: () => this.#availableServers,

        getServerPreferences: (currentServerValue?: string) => {
            return this.createServerPreferences(
                this.#availableServers,
                currentServerValue,
            );
        },

        validateServer: (server) => {
            return this.#availableServers.some((s) => s.value === server);
        },
    };

    override getFilterConfig: GetFilterConfig = () => ({
        extensionId: this.extensionMetadata.id,
        extensionName: this.name,
        supportedFilters: [],
    });

    #parseSearchResult(html: string): SeriesListResponse<Manga> {
        const $ = cheerio.load(html);

        const $container = $("#book_list");

        if (!$container.length) return { data: [] };

        const mangaList: Manga[] = [];

        $container.find(".item").each((_, el) => {
            const $el = $(el);

            const $titleSelector = $el.find("h3");
            const url = $titleSelector.find("a").attr("href");
            const title = $titleSelector.find("a").text();
            const description = $el.find(".summary").text().trim();
            const coverImageUrl = $el.find("a img").attr("src") || null;
            const statusText = $el.find(".status").text();

            const genres = $el
                .find(".genres a")
                .get()
                .map((el) => $(el).text().trim())
                .filter(Boolean);

            mangaList.push({
                id: `series-${this.slugify(title)}`,
                extensionId: this.extensionMetadata.id,
                title,
                url: this.getUrlPath(url || ""),
                coverImageUrl,
                status: this.getSeriesStatus(statusText),
                isNsfw:
                    genres?.length > 0
                        ? this.detectNsfw(title, description, genres)
                        : null,
                source: this.name,
                isLocal: false,
                genres,
            });
        });

        const lastPageHref = $(
            ".uk-pagination li:last-child a.page-numbers",
        ).attr("href");
        const lastPage = lastPageHref
            ? Number.parseInt(
                  new URL(lastPageHref, this.baseUrl).pathname
                      .split("/")
                      ?.filter(Boolean)
                      ?.pop() || "1",
                  10,
              )
            : 1;

        const currentPage =
            Number.parseInt(
                $(".uk-pagination li.uk-active .current").text().trim(),
                10,
            ) || 1;

        const hasMore = currentPage < lastPage;
        const nextPage = hasMore ? currentPage + 1 : null;

        return {
            data: mangaList,
            pagination: {
                hasMore,
                nextPage,
            },
        };
    }

    #parseManga(html: string): Manga | null {
        const $ = cheerio.load(html);

        const $container = $("#single_book");

        if (!$container.length) return null;

        const title = $container.find("h1.heading").text().trim();

        const alternateTitles = $container
            .find(".alt_name")
            .text()
            ?.split(";")
            .map((el) => el.trim())
            .filter(Boolean);

        const description = $container.find(".summary p").text().trim();

        const coverImageUrl = $container.find("img").attr("src") || null;

        const statusText = $container.find(".d-row-small .status").text();

        const genres = $container
            .find(".genres a")
            .get()
            .map((el) => $(el).text().trim())
            .filter(Boolean);

        const lastUpdated = this.parseSeriesDate(
            $container.find(".updateAt").text().trim(),
        );

        const authors = $container
            .find(".authors a")
            .get()
            .map((el) => $(el).text().trim())
            .filter(Boolean);

        return {
            id: `single-series-${this.slugify(title)}`,
            extensionId: this.extensionMetadata.id,
            title,
            description,
            coverImageUrl,
            source: this.name,
            status: this.getSeriesStatus(statusText),
            genres,
            isNsfw: this.detectNsfw(title, description, genres),
            lastUpdated,
            alternateTitles,
            authors,
            isLocal: false,
            url: this.getUrlPath(
                $('meta[property="og:url"]').attr("content") || "",
            ),
            artists: authors,
        };
    }
}
