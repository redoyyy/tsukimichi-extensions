import type { ExtensionMetadata } from "@tsukimichi-extensions/common";

export const METADATA: ExtensionMetadata = {
    id: "1f5fd8a0-30cd-4722-bdbc-e1e683b2dd12",
    name: "MangaKatana",
    description: "",
    isManga: true,
    containsNSFWContent: true,
    isNSFWFocused: false,
    minAppVersion: "1.0.0",
    url: "https://mangakatana.com",
    iconUrl:
        "https://t0.gstatic.com/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&url=https://mangakatana.com&size=128",
    version: "",
    apiUrl: "",
};
