export const MANGA_KATANA_GENRES = [
    { label: "4 koma", value: "4-koma", nsfw: false },
    { label: "Action", value: "action", nsfw: false },
    { label: "Adult", value: "adult", nsfw: true },
    { label: "Adventure", value: "adventure", nsfw: false },
    { label: "Artbook", value: "artbook", nsfw: false },
    { label: "Award winning", value: "award-winning", nsfw: false },
    { label: "Comedy", value: "comedy", nsfw: false },
    { label: "Cooking", value: "cooking", nsfw: false },
    { label: "Doujinshi", value: "doujinshi", nsfw: false },
    { label: "Drama", value: "drama", nsfw: false },
    { label: "Ecchi", value: "ecchi", nsfw: true },
    { label: "Erotica", value: "erotica", nsfw: true },
    { label: "Fantasy", value: "fantasy", nsfw: false },
    { label: "Gender Bender", value: "gender-bender", nsfw: false },
    { label: "Gore", value: "gore", nsfw: true },
    { label: "Harem", value: "harem", nsfw: false },
    { label: "Historical", value: "historical", nsfw: false },
    { label: "Horror", value: "horror", nsfw: false },
    { label: "Isekai", value: "isekai", nsfw: false },
    { label: "Josei", value: "josei", nsfw: false },
    { label: "Loli", value: "loli", nsfw: true },
    { label: "Manhua", value: "manhua", nsfw: false },
    { label: "Manhwa", value: "manhwa", nsfw: false },
    { label: "Martial Arts", value: "martial-arts", nsfw: false },
    { label: "Mecha", value: "mecha", nsfw: false },
    { label: "Medical", value: "medical", nsfw: false },
    { label: "Music", value: "music", nsfw: false },
    { label: "Mystery", value: "mystery", nsfw: false },
    { label: "One shot", value: "one-shot", nsfw: false },
    { label: "Overpowered MC", value: "overpowered-mc", nsfw: false },
    { label: "Psychological", value: "psychological", nsfw: false },
    { label: "Reincarnation", value: "reincarnation", nsfw: false },
    { label: "Romance", value: "romance", nsfw: false },
    { label: "School Life", value: "school-life", nsfw: false },
    { label: "Sci-fi", value: "sci-fi", nsfw: false },
    { label: "Seinen", value: "seinen", nsfw: false },
    { label: "Sexual violence", value: "sexual-violence", nsfw: true },
    { label: "Shota", value: "shota", nsfw: true },
    { label: "Shoujo", value: "shoujo", nsfw: false },
    { label: "Shoujo Ai", value: "shoujo-ai", nsfw: false },
    { label: "Shounen", value: "shounen", nsfw: false },
    { label: "Shounen Ai", value: "shounen-ai", nsfw: false },
    { label: "Slice of Life", value: "slice-of-life", nsfw: false },
    { label: "Sports", value: "sports", nsfw: false },
    { label: "Super power", value: "super-power", nsfw: false },
    { label: "Supernatural", value: "supernatural", nsfw: false },
    { label: "Survival", value: "survival", nsfw: false },
    { label: "Time Travel", value: "time-travel", nsfw: false },
    { label: "Tragedy", value: "tragedy", nsfw: false },
    { label: "Webtoon", value: "webtoon", nsfw: false },
    { label: "Yaoi", value: "yaoi", nsfw: true },
    { label: "Yuri", value: "yuri", nsfw: true },
];

export const MANGA_KATANA_GENRES_INCLUSION_MODE = [
    {
        label: "AND (All Selected Genres)",
        value: "and",
    },
    {
        label: "OR (Any Selected Genres)",
        value: "or",
    },
];

export const MANGA_KATANA_ORDER_BY_OPTIONS = [
    {
        label: "Latest",
        value: "latest",
    },
    {
        label: "New Manga",
        value: "new",
    },
    {
        label: "Alphabetical (A-Z)",
        value: "az",
    },
];

export const MANGA_KATANA_STATUS = [
    {
        label: "Cancelled",
        value: "0",
    },
    {
        label: "Ongoing",
        value: "1",
    },
    {
        label: "Completed",
        value: "2",
    },
];
