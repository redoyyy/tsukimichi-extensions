import { MangaReader } from "@/lib/multi-src/manga-reader";

import manifest from "./manifest.json";

export class ArcaneScans extends MangaReader {
    override requireCoverImageProxy = false;

    constructor() {
        super(manifest);
    }

    protected override ratingSelector = ".rating .numscore";
    protected override seriesDetailsGenresSelector =
        '.mgen a[href*="/genres/"]';
}
