import type { ExtensionMetadata } from "@tsukimichi-extensions/common";

export const METADATA: ExtensionMetadata = {
    id: "89ba0b98-4bb9-448e-ba6b-5c1d3414fa52",
    name: "ArcaneScans",
    description: "",
    isManga: true,
    containsNSFWContent: true,
    isNSFWFocused: false,
    minAppVersion: "1.0.0",
    url: "https://arcanescans.com",
    iconUrl:
        "https://t0.gstatic.com/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&url=https://arcanescans.com&size=128",
    version: "",
    apiUrl: "",
};
