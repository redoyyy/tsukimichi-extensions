import { MangaBox } from "@/lib/multi-src/manga-box";
import type { GetImage } from "@tsukimichi-extensions/common";
import manifest from "./manifest.json";

export class MangaKakalot extends MangaBox {
    override requireCoverImageProxy = true;
    override requireChapterImageProxy = true;

    constructor() {
        super(manifest);
    }

    override getImage: GetImage = async (imageUrl) => {
        const imageHeaders = super.getImageHeaders();
        imageHeaders.set("Referer", "https://www.mangakakalot.gg/");

        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 2000);

        const response = await fetch(imageUrl, {
            headers: imageHeaders,
            signal: controller.signal,
        });

        clearTimeout(timeout);

        if (!response.ok) {
            throw new Error(`Failed to fetch image: ${response.statusText}`);
        }

        const arrayBuffer = await response.arrayBuffer();

        return {
            data: arrayBuffer,
            contentType: response.headers.get("content-type") || "image/jpeg",
        };
    };
}
