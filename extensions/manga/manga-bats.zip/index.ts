import { MangaBox } from "@/lib/multi-src/manga-box";
import type { GetImage } from "@tsukimichi-extensions/common";

import manifest from "./manifest.json";

export class MangaBats extends MangaBox {
    override requireCoverImageProxy = true;
    override requireChapterImageProxy = true;

    constructor() {
        super(manifest);
    }

    override getImage: GetImage = async (url) => {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 4000);
        const imageHeaders = this.getImageHeaders();

        const response = await fetch(url, {
            headers: {
                ...imageHeaders,
                Referer: "https://www.mangabats.com/",
            },
            signal: controller.signal,
        });

        clearTimeout(timeout);

        if (!response.ok) {
            throw new Error(`Failed to fetch image: ${response.statusText}`);
        }

        const arrayBuffer = await response.arrayBuffer();

        return {
            data: arrayBuffer,
            contentType: response.headers.get("content-type") || "image/jpeg",
        };
    };
}
