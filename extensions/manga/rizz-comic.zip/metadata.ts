import type { ExtensionMetadata } from "@tsukimichi-extensions/common";

export const METADATA: ExtensionMetadata = {
    id: "b94584d8-23cb-49e6-a00c-53c0aad97f16",
    name: "RizzComic",
    url: "https://rizzcomic.com",
    iconUrl:
        "https://t0.gstatic.com/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&url=https://rizzcomic.com&size=128",
    description: "",
    isManga: true,
    containsNSFWContent: true,
    isNSFWFocused: false,
    minAppVersion: "1.0.0",
    version: "",
    apiUrl: "",
};
