import { MangaReader } from "@/lib/multi-src/manga-reader";
import metadata from "./manifest.json";

export class RizzComic extends MangaReader {
    override requireCoverImageProxy = false;
    override requireChapterImageProxy = false;

    constructor() {
        super(metadata);
    }

    protected override ratingSelector = ".rating .numscore";
    protected override seriesDetailsGenresSelector =
        '.mgen a[href*="/genres/"]';
}
