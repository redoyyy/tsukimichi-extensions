export const MANGA_18X_ORDER_BY_OPTIONS = [
    { label: "Relevance", value: "relevance" },
    { label: "Latest", value: "latest" },
    { label: "Alphabetical(A-Z)", value: "alphabet" },
    { label: "Rating", value: "rating" },
    { label: "Trending", value: "trending" },
    { label: "Most Views", value: "views" },
    { label: "New Manga", value: "new-manga" },
];
