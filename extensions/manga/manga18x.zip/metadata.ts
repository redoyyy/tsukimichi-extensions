import type { ExtensionMetadata } from "@tsukimichi-extensions/common";

export const METADATA: ExtensionMetadata = {
    id: "c83cab9b-eaab-4f74-b290-b89a4fa9c201",
    name: "Manga18x",
    isManga: true,
    containsNSFWContent: true,
    isNSFWFocused: true,
    iconUrl:
        "https://t0.gstatic.com/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&url=https://manga18x.net&size=128",
    minAppVersion: "1.0.0",
    url: "https://manga18x.net",
    description: "",
    version: "",
    apiUrl: "",
};
