import type {
    GetFilterConfig,
    SelectFilter,
} from "@tsukimichi-extensions/common";

import { Madara } from "@/lib/multi-src/madara";
import { MANGA_18X_ORDER_BY_OPTIONS } from "./filters";
import manifest from "./manifest.json";

export class Manga18x extends Madara {
    constructor() {
        super(manifest);
    }

    override getFilterConfig: GetFilterConfig = () => {
        return {
            extensionId: this.extensionMetadata.id,
            extensionName: this.extensionMetadata.name,
            supportedFilters: [
                {
                    key: "m_orderby",
                    label: "Order By",
                    options: MANGA_18X_ORDER_BY_OPTIONS,
                    type: "select",
                    multiple: false,
                } as SelectFilter,
            ],
        };
    };

    protected override searchSeriesSelector =
        ".c-tabs-item .row.c-tabs-item__content";
    protected override genreSelector = "a[href*='/manga-genre/']";
    protected override artistSelector = "a[href*='/manga-artist/']";
    protected override authorSelector = "a[href*='/manga-author/']";
    protected override currentPageSelector = ".wp-pagenavi span.current";
    protected override nextPageSelector =
        '.wp-pagenavi a.nextpostslink[rel="next"]';
    protected override mangaSubString = "manga";
    protected override seriesSelector = ".tab-summary";
}
