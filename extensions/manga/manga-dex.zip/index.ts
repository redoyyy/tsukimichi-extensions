import type {
    Chapter,
    Filter,
    GetFilterConfig,
    GetLatestSeries,
    GetMangaChapterDetails,
    GetMangaChapters,
    GetPopularSeries,
    GetSeries,
    Manga,
    MultiSelectFilter,
    ScrapingOptions,
    SearchSeries,
    SelectFilter,
    SeriesListResponse,
} from "@tsukimichi-extensions/common";

import { BaseMangaScraper } from "@/generic/base-manga-scraper";
import { getLanguageKey } from "@/utils/language";
import {
    MANGA_DEX_CONTENT_RATINGS,
    MANGA_DEX_DEMOGRAPHICS,
    MANGA_DEX_FORMATS,
    MANGA_DEX_GENRES,
    MANGA_DEX_SORT_BY_OPTIONS,
    MANGA_DEX_SORT_ORDER_OPTIONS,
    MANGA_DEX_STATUSES,
    MANGA_DEX_TAG_SEARCH_OPTIONS,
    MANGA_DEX_THEMES,
} from "./filters";
import manifest from "./manifest.json";

export class MangaDex extends BaseMangaScraper {
    override supportsLatest = true;
    override supportsPopular = true;
    override requireCoverImageProxy = false;

    #apiUrl = "https://api.mangadex.org";

    constructor() {
        super(manifest);
    }

    override searchSeries: SearchSeries<Manga> = async (query, options) => {
        const { page = 1, limit = 32, filters } = options?.searchOptions ?? {};
        const url = new URL("manga", this.#apiUrl);
        url.searchParams.set("title", query);
        url.searchParams.set("offset", ((page - 1) * limit).toString());
        url.searchParams.set("limit", limit.toString());
        ["artist", "author", "cover_art"].forEach((name) =>
            url.searchParams.append("includes[]", name),
        );

        const config = this.getFilterConfig({
            includeNsfw: filters?.includeNsfw,
        });
        const filterMap = new Map<string, Filter>(
            config.supportedFilters.map((f) => [f.key, f]),
        );

        const sortOrder = filters?.["sortOrder"] || "desc";

        // In MangaDex, not specifying content rating is the same as specifying all
        if (!filters?.["contentRating[]"]) {
            MANGA_DEX_CONTENT_RATINGS.forEach((v) =>
                url.searchParams.append("contentRating[]", v.value?.toString()),
            );
        }

        for (const [key, value] of Object.entries(filters ?? {})) {
            const filter = filterMap.get(key);
            if (!filter || value === undefined || value === null) continue;

            switch (filter.type) {
                case "select":
                    if (typeof value === "string" && key === "order") {
                        if (value !== "any") {
                            url.searchParams.set(`${key}[${value}]`, sortOrder);
                        }
                    }
                    if (key === "sortOrder" || key === "order") break;
                    if (value !== "any") {
                        url.searchParams.set(key, value?.toString());
                    }
                    break;
                case "multi-select":
                    if (Array.isArray(value)) {
                        value.forEach((v) => {
                            if (v !== "any") {
                                url.searchParams.append(key, v?.toString());
                            }
                        });
                    }
                    break;
            }
        }

        const response = await this.fetchWithRetry(url.toString(), 2, options);
        const json = await response.json();

        return this.#parseSearchResults(json, limit);
    };

    override getPopularSeries: GetPopularSeries<Manga> = async (options) => {
        const url = new URL("manga", this.#apiUrl);
        const searchParams = this.#buildSearchListingParams("popular", options);
        const finalUrl = `${url.toString()}?${searchParams.toString()}`;

        const response = await this.fetchWithRetry(finalUrl, 3, options);
        const json = await response.json();

        return this.#parseSearchResults(json);
    };

    override getLatestSeries: GetLatestSeries<Manga> = async (options) => {
        const url = new URL("manga", this.#apiUrl);
        const searchParams = this.#buildSearchListingParams("latest", options);
        const finalUrl = `${url.toString()}?${searchParams.toString()}`;

        const response = await this.fetchWithRetry(finalUrl, 3, options);
        const json = await response.json();

        return this.#parseSearchResults(json);
    };

    override getSeries: GetSeries<Manga> = async (query) => {
        const url = new URL(query, this.#apiUrl);
        ["artist", "author", "cover_art"].forEach((name) =>
            url.searchParams.append("includes[]", name),
        );

        const response = await this.fetchWithRetry(url.toString(), 0);
        const json = await response.json();

        if (!("data" in json) || json.data === undefined) return null;

        return this.#parseManga(json.data);
    };

    override getChapters: GetMangaChapters = async (query) => {
        const url = new URL(`${query}/feed`, this.#apiUrl);
        const chaptersList: Chapter[] = [];

        let offset = 0;
        let foundAllChapters = false;
        while (!foundAllChapters) {
            url.searchParams.set("offset", offset.toString());
            url.searchParams.set("limit", "500");
            url.searchParams.set("includes[]", "scanlation_group");
            MANGA_DEX_CONTENT_RATINGS.forEach((r) =>
                url.searchParams.append("contentRating[]", r.value.toString()),
            );
            ["order[chapter]", "order[volume]"].forEach((item) =>
                url.searchParams.append(item, "asc"),
            );

            const response = await this.fetchWithRetry(url.toString(), 0);
            const json = await response.json();

            if (!("data" in json) || json.data === undefined) return [];

            json.data.forEach((chapter: any) => {
                const groupRelationship = chapter.relationships.find(
                    (relationship: any) =>
                        relationship.type === "scanlation_group" &&
                        relationship.attributes !== undefined,
                );
                const groupName = groupRelationship
                    ? groupRelationship?.attributes?.name
                    : "";

                chaptersList.push({
                    id: chapter.id,
                    extensionId: this.extensionMetadata.id,
                    source: this.name,
                    title: `Chapter ${chapter.attributes.chapter}`,
                    chapterNumber: chapter.attributes.chapter,
                    volumeNumber: chapter.attributes.volume,
                    languageKey:
                        getLanguageKey(chapter.attributes.translatedLanguage) ||
                        "multi",
                    url: `/${chapter.id}`,
                    imageUrls: [],
                    totalPages: chapter.attributes.pages,
                    groupName,
                    lastUpdated: this.parseSeriesDate(
                        chapter.attributes?.updatedAt,
                    ),
                });
            });

            if (json.total > offset + 500) {
                offset += 500;
            } else {
                foundAllChapters = true;
            }
        }

        return this.addChapterNavigation(chaptersList) || [];
    };

    override getChapter: GetMangaChapterDetails = async (query, options) => {
        const { useDataSaver = true, mangaId } =
            options?.searchOptions?.filters ?? {};

        if (!mangaId) throw new Error("Manga ID not found in search filters");

        const url = new URL(`at-home/server${query}`, this.#apiUrl);

        const imagesResponse = await this.fetchWithRetry(url.toString(), 3);
        const imagesJson = await imagesResponse.json();

        if (!("chapter" in imagesJson) || !("data" in imagesJson.chapter))
            return null;

        const imageUrls: string[] = [];

        if (useDataSaver && typeof useDataSaver === "boolean") {
            imagesJson.chapter.dataSaver.forEach((item: string) =>
                imageUrls.push(
                    `${imagesJson.baseUrl}/data-saver/${imagesJson.chapter.hash}/${item}`,
                ),
            );
        } else {
            imagesJson.chapter.data.forEach((item: string) =>
                imageUrls.push(
                    `${imagesJson.baseUrl}/data/${imagesJson.chapter.hash}/${item}`,
                ),
            );
        }

        if (!imageUrls.length) return null;

        const chapters = await this.getChapters(`/manga/${mangaId}`);
        const chapter = chapters.find((c) => c.id === query.split("/")?.pop());
        if (!chapter) return null;

        return {
            ...chapter,
            imageUrls,
            totalPages: imageUrls.length || chapter.totalPages,
        };
    };

    override getFilterConfig: GetFilterConfig = (params) => {
        const includeNsfw = params?.includeNsfw ?? false;

        const contentRatingOptions = MANGA_DEX_CONTENT_RATINGS.map((option) => {
            const isNsfw =
                option.value === "erotica" || option.value === "pornographic";
            return includeNsfw ? option : { ...option, disabled: isNsfw };
        });

        const filterNsfwOptions = (options: any[]) => {
            return options.map((option) => {
                return includeNsfw
                    ? option
                    : { ...option, disabled: option.nsfw };
            });
        };

        return {
            extensionId: this.extensionMetadata.id,
            extensionName: this.name,
            supportedFilters: [
                {
                    key: "status[]",
                    label: "Status",
                    multiple: true,
                    options: MANGA_DEX_STATUSES,
                    type: "multi-select",
                    renderAs: "select",
                } as MultiSelectFilter,
                {
                    key: "contentRating[]",
                    label: "Content Rating",
                    multiple: true,
                    options: contentRatingOptions,
                    type: "multi-select",
                    renderAs: "select",
                } as MultiSelectFilter,
                {
                    key: "publicationDemographic[]",
                    label: "Demographics",
                    multiple: true,
                    options: MANGA_DEX_DEMOGRAPHICS,
                    type: "multi-select",
                    renderAs: "select",
                } as MultiSelectFilter,
                {
                    key: "order",
                    label: "Sort By",
                    multiple: false,
                    options: MANGA_DEX_SORT_BY_OPTIONS,
                    type: "select",
                } as SelectFilter,
                {
                    key: "sortOrder",
                    label: "Sort Order",
                    multiple: false,
                    options: MANGA_DEX_SORT_ORDER_OPTIONS,
                    type: "select",
                } as SelectFilter,
                {
                    key: "includedTagsMode",
                    label: "Tag Search Mode",
                    multiple: false,
                    options: MANGA_DEX_TAG_SEARCH_OPTIONS,
                    type: "select",
                } as SelectFilter,
                {
                    key: "includedTags[]",
                    label: "Genres",
                    multiple: true,
                    options: filterNsfwOptions(MANGA_DEX_GENRES),
                    type: "multi-select",
                    renderAs: "checkbox-group",
                } as MultiSelectFilter,
                {
                    key: "includedTags[]",
                    label: "Themes",
                    multiple: true,
                    options: filterNsfwOptions(MANGA_DEX_THEMES),
                    type: "multi-select",
                    renderAs: "checkbox-group",
                } as MultiSelectFilter,
                {
                    key: "includedTags[]",
                    label: "Formats",
                    multiple: true,
                    options: filterNsfwOptions(MANGA_DEX_FORMATS),
                    type: "multi-select",
                    renderAs: "checkbox-group",
                } as MultiSelectFilter,
            ],
        };
    };

    #buildSearchListingParams(
        type: "popular" | "latest",
        options?: ScrapingOptions,
    ): URLSearchParams {
        const { page = 1, limit = 32, filters } = options?.searchOptions ?? {};
        const searchParams = new URLSearchParams();
        searchParams.set("offset", ((page - 1) * limit).toString());
        searchParams.set("limit", limit.toString());
        ["artist", "author", "cover_art"].forEach((name) =>
            searchParams.append("includes[]", name),
        );
        searchParams.set(
            `order[${type === "popular" ? "followedCount" : "createdAt"}]`,
            "desc",
        );

        if (filters?.includeNsfw) {
            MANGA_DEX_CONTENT_RATINGS.forEach((v) =>
                searchParams.append("contentRating[]", v.value),
            );
        } else {
            searchParams.append("contentRating[]", "safe");
            searchParams.append("contentRating[]", "suggestive");
        }

        return searchParams;
    }

    #parseManga(item: any): Manga {
        const title = (item?.attributes?.title?.en ||
            Object.values(item?.attributes?.title || {})[0]) as string;

        const alternateTitles = item?.attributes?.altTitles?.flatMap((t: any) =>
            Object.values(t),
        );

        const description = item?.attributes?.description?.en;

        const coverRelationship = item.relationships.find(
            (r: any) => r.type === "cover_art" && r.attributes !== undefined,
        );
        const coverImageUrl = coverRelationship
            ? `https://uploads.mangadex.org/covers/${item.id}/${coverRelationship.attributes?.fileName}`
            : null;

        const authors = item.relationships
            .filter(
                (relationship: any) =>
                    relationship.type === "author" &&
                    relationship.attributes !== undefined,
            )
            .map((relationship: any) => relationship.attributes.name);

        const artists = item.relationships
            .filter(
                (relationship: any) =>
                    relationship.type === "artist" &&
                    relationship.attributes !== undefined,
            )
            .map((relationship: any) => relationship.attributes.name);

        const tags = item.attributes.tags
            .filter((tag: any) => tag?.attributes?.group !== "genre")
            .map((tag: any) => tag.attributes.name.en);

        const genres = item.attributes.tags
            .filter((tag: any) => tag?.attributes?.group === "genre")
            .map((tag: any) => tag?.attributes?.name?.en);

        return {
            id: item.id,
            extensionId: this.extensionMetadata.id,
            source: this.name,
            title,
            alternateTitles,
            description,
            tags,
            genres,
            coverImageUrl,
            isNsfw:
                item.attributes?.contentRating === "erotica" ||
                item.attributes?.contentRating === "pornographic" ||
                this.detectNsfw(title, description, genres, tags),
            status: this.getSeriesStatus(item.attributes.status),
            url: `/manga/${item.id}`,
            lastUpdated: this.parseSeriesDate(item.attributes.updatedAt),
            authors,
            artists,
            isLocal: false,
        };
    }

    #parseSearchResults(json: any, limit = 32): SeriesListResponse<Manga> {
        if (!("data" in json) || json.data === undefined || !json.data.length) {
            return {
                data: [],
                pagination: {
                    hasMore: false,
                    nextPage: null,
                },
            };
        }

        const mangaList: Manga[] = json.data.map((item: any) =>
            this.#parseManga(item),
        );

        const hasMore = json.total > json.offset + mangaList.length;
        const nextPage = hasMore ? Math.floor(json.offset / limit) + 2 : null;

        return {
            data: mangaList,
            pagination: {
                hasMore,
                nextPage,
            },
        };
    }
}
