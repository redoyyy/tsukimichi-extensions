import type { ExtensionMetadata } from "@tsukimichi-extensions/common";

export const METADATA: ExtensionMetadata = {
    id: "be7645dc-c8ad-40a0-a99d-3b7628557ea7",
    name: "MangaDex",
    url: "https://mangadex.org",
    iconUrl:
        "https://t0.gstatic.com/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&url=https://mangadex.org&size=128",
    isManga: true,
    containsNSFWContent: true,
    isNSFWFocused: false,
    minAppVersion: "1.0.0",
    description: "",
    version: "",
    apiUrl: "https://api.mangadex.org",
};
