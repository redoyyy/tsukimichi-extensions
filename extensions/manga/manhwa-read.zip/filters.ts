export const MANHWA_READ_GENRES = [
    {
        label: "Action",
        value: 650,
    },
    {
        label: "Adventure",
        value: 645,
    },
    {
        label: "Comedy",
        value: 536,
    },
    {
        label: "Drama",
        value: 530,
    },
    {
        label: "Ecchi",
        value: 537,
    },
    {
        label: "Fantasy",
        value: 646,
    },
    {
        label: "Hentai",
        value: 531,
    },
    {
        label: "Horror",
        value: 590,
    },
    {
        label: "Isekai",
        value: 2735,
    },
    {
        label: "Mahou Shoujo",
        value: 2696,
    },
    {
        label: "Mystery",
        value: 626,
    },
    {
        label: "Psychological",
        value: 591,
    },
    {
        label: "Romance",
        value: 538,
    },
    {
        label: "Sci-Fi",
        value: 688,
    },
    {
        label: "Slice of Life",
        value: 532,
    },
    {
        label: "Sports",
        value: 677,
    },
    {
        label: "Supernatural",
        value: 544,
    },
    {
        label: "Thriller",
        value: 580,
    },
];

export const MANHWA_READ_SORT_BY_OPTIONS = [
    {
        label: "Release",
        value: "release",
    },
    {
        label: "New",
        value: "new",
    },
    {
        label: "Alphabetical(A-Z)",
        value: "alphabet",
    },
    {
        label: "Rating",
        value: "rating",
    },
    {
        label: "Chapters",
        value: "chapters",
    },
    {
        label: "Daily Views",
        value: "daily_top",
    },
    {
        label: "Weekly Views",
        value: "weekly_top",
    },
    {
        label: "Monthly Views",
        value: "monthly_top",
    },
    {
        label: "Yearly Views",
        value: "yearly_top",
    },
    {
        label: "All Time Views",
        value: "all_top",
    },
];

export const MANHWA_READ_STATUS = [
    {
        label: "All",
        value: "all",
    },
    {
        label: "Ongoing",
        value: "ongoing",
    },
    {
        label: "Completed",
        value: "completed",
    },
    {
        label: "Cancelled",
        value: "canceled",
    },
    {
        label: "Hiatus",
        value: "on-hold",
    },
    {
        label: "Incomplete",
        value: "incomplete",
    },
];

export const MANHWA_READ_KEYWORD_MODE = [
    {
        label: "Contain",
        value: "contains",
    },
    {
        label: "Start With",
        value: "start-with",
    },
    {
        label: "End With",
        value: "end-with",
    },
];

export const MANHWA_READ_TAG_SEARCH_OPTIONS = [
    { label: "AND (All Selected Genres)", value: "AND" },
    { label: "OR (Any Selected Genres)", value: "OR" },
];
