import type {
    Chapter,
    Filter,
    GetFilterConfig,
    GetMangaChapterDetails,
    GetMangaChapters,
    MultiSelectFilter,
    ScrapingOptions,
    SelectFilter,
} from "@tsukimichi-extensions/common";
import * as cheerio from "cheerio";

import { Madara } from "@/lib/multi-src/madara";
import {
    MANHWA_READ_GENRES,
    MANHWA_READ_KEYWORD_MODE,
    MANHWA_READ_SORT_BY_OPTIONS,
    MANHWA_READ_STATUS,
    MANHWA_READ_TAG_SEARCH_OPTIONS,
} from "./filters";
import manifest from "./manifest.json";

export class ManhwaRead extends Madara {
    override requireChapterImageProxy = true;

    constructor() {
        super(manifest);
    }

    protected override searchMangaRequest(
        query: string,
        options?: ScrapingOptions,
    ): Promise<Response> {
        const { page = 1, filters } = options?.searchOptions ?? {};
        const pageNumStr = Math.max(page, 1).toString();
        const url = new URL(`page/${pageNumStr}`, this.baseUrl);
        url.searchParams.set("s", query);
        url.searchParams.set("post_type", "wp-manga");

        const config = this.getFilterConfig();
        const filterMap = new Map<string, Filter>(
            config.supportedFilters.map((f) => [f.key, f]),
        );

        for (const [key, value] of Object.entries(filters ?? {})) {
            const filter = filterMap.get(key);
            if (!filter || value === null || value === undefined) continue;

            switch (filter.type) {
                case "select":
                    if (typeof value === "string" && value?.trim()) {
                        url.searchParams.set(key, value?.toString());
                    }
                    break;
                case "multi-select":
                    if (
                        Array.isArray(value) &&
                        value.length > 0 &&
                        filter.renderAs === "checkbox-group"
                    ) {
                        value.forEach((v) =>
                            url.searchParams.append(key, v?.toString()),
                        );
                    }
                    break;
            }
        }

        return fetch(url.toString(), options?.init);
    }

    override getChapters: GetMangaChapters = async (query) => {
        const url = new URL(`${this.mangaSubString}${query}`, this.baseUrl);

        const html = await this.fetchHtml(url.toString());

        const $ = cheerio.load(html);

        const $chaptersList = $("#groupChapterList > #chaptersList a");
        if (!$chaptersList.length) return [];

        const chapters: Chapter[] = [];

        $chaptersList.each((_, el) => {
            const $el = $(el);

            const titleFromEl = $el.find(".chapter-item__name").text().trim();
            const chapterNumber = this.extractChapterNumber(titleFromEl);

            const lastUpdated = this.parseSeriesDate(
                $el.find(".chapter-item__date").text().trim(),
            );

            chapters.push({
                id: `chapter-${this.slugify(titleFromEl)}`,
                extensionId: this.extensionMetadata.id,
                title: chapterNumber ? `Chapter ${chapterNumber}` : titleFromEl,
                source: this.name,
                lastUpdated,
                url: this.getUrlPath($el.attr("href") || "")?.replace(
                    `/${this.mangaSubString}`,
                    "",
                ),
                imageUrls: [],
                languageKey: "en",
                totalPages: 0,
                groupName: null,
                volumeNumber: null,
                chapterNumber,
                nextChapter: null,
                previousChapter: null,
            });
        });

        return this.addChapterNavigation(chapters) || [];
    };

    override getChapter: GetMangaChapterDetails = async (query) => {
        const url = new URL(`${this.mangaSubString}${query}`, this.baseUrl);

        const html = await this.fetchHtml(url.toString());
        const $ = cheerio.load(html);

        const imageUrls: string[] = [];

        const data = this.#getImagesAndCdnUrl(html);

        data.images.forEach((url) => {
            imageUrls.push(`${data.baseUrl}/${url}`);
        });

        if (!imageUrls.length) return null;

        const title = $("#readingNavTop .container h1").text();

        return {
            id: `single-chapter-${this.slugify(title)}`,
            extensionId: this.extensionMetadata.id,
            title: title,
            url: this.getUrlPath(url.toString())?.replace(
                `/${this.mangaSubString}`,
                "",
            ),
            totalPages: imageUrls.length,
            imageUrls,
            languageKey: "en",
            source: this.name,
            groupName: null,
            volumeNumber: null,
            chapterNumber: this.getLargestNumber([title])?.toString(),
            lastUpdated: null,
            nextChapter: null,
            previousChapter: null,
        };
    };

    protected override async popularMangaRequest(
        options?: ScrapingOptions,
    ): Promise<Response> {
        const { page = 1 } = options?.searchOptions ?? {};
        const pageNumStr = Math.max(page, 1).toString();
        const url = new URL(
            `${this.mangaSubString}/page/${pageNumStr}`,
            this.baseUrl,
        );
        url.searchParams.set("s", "");
        url.searchParams.set("sortby", "all_top");
        return fetch(url.toString());
    }

    protected override async latestMangaRequest(
        options?: ScrapingOptions,
    ): Promise<Response> {
        const { page = 1 } = options?.searchOptions ?? {};
        const pageNumStr = Math.max(page, 1).toString();
        const url = new URL(
            `${this.mangaSubString}/page/${pageNumStr}`,
            this.baseUrl,
        );
        url.searchParams.set("s", "");
        url.searchParams.set("sortby", "release");
        return fetch(url.toString());
    }

    override getFilterConfig: GetFilterConfig = () => {
        return {
            extensionId: this.extensionMetadata.id,
            extensionName: this.name,
            supportedFilters: [
                {
                    key: "status",
                    label: "Status",
                    options: MANHWA_READ_STATUS,
                    type: "select",
                    multiple: false,
                } as SelectFilter,
                {
                    key: "sortby",
                    label: "Sort By",
                    options: MANHWA_READ_SORT_BY_OPTIONS,
                    type: "select",
                    multiple: false,
                } as SelectFilter,
                {
                    key: "keyword_mode",
                    label: "Keyword Mode",
                    description:
                        "Select how the keyword should match the title (anywhere, beginning, or end).",
                    options: MANHWA_READ_KEYWORD_MODE,
                    type: "select",
                    multiple: false,
                } as SelectFilter,
                {
                    key: "s_mode",
                    label: "Tag Search Mode",
                    options: MANHWA_READ_TAG_SEARCH_OPTIONS,
                    type: "select",
                    multiple: false,
                } as SelectFilter,
                {
                    key: "genres[]",
                    label: "Genres",
                    options: MANHWA_READ_GENRES,
                    type: "multi-select",
                    multiple: true,
                    renderAs: "checkbox-group",
                } as MultiSelectFilter,
            ],
        };
    };

    protected override searchSeriesSelector = ".manga-grid .manga-item";
    protected override genreSelector = ".manga-item__genres span";
    protected override tagSelector = ".manga-item__tags span";
    protected override statusSelector = ".manga-status__label";
    protected override mangaSubString = "manhwa";
    protected override seriesSelector = "#mangaSummary";

    protected override seriesDetailsTagSelector =
        "a[href*='/tag/'] span:first-child";
    protected override seriesDetailsGenreSelector = 'a[href*="/genre/"]';
    protected override seriesDetailsArtistSelector =
        'a[href*="/artist/"] span:first-child';
    protected override seriesDetailsAuthorSelector =
        'a[href*="/author/"] span:first-child';
    protected override seriesDetailsStatusSelector =
        "span.manga-status__label span:nth-of-type(2)";
    protected override seriesDetailsAlternateTitleSelector = ".manga-titles h2";
    protected override seriesDetailsRatingSelector = ".rating__current";
    protected override seriesDetailsDescriptionSelector =
        ".manga-desc__content p";

    protected override alternateTitleDelimiter = "|";

    #getImagesAndCdnUrl(html: string): { baseUrl: string; images: string[] } {
        const $ = cheerio.load(html);
        const singleChapterScript = $("script#single-chapter-js-extra").text();

        const singleChapterMatch = singleChapterScript.match(
            /var\s+chapterData\s*=\s*(\{.*?\});/s,
        );

        let baseUrl: string | null = null;
        const images: string[] = [];

        if (singleChapterMatch?.[1]) {
            const chapterData = JSON.parse(singleChapterMatch[1]);
            baseUrl = chapterData.base;
            JSON.parse(this.#base64ToUtf8(chapterData.data))?.forEach(
                (item: any) => {
                    if (
                        item?.src !== "" ||
                        item?.src !== undefined ||
                        item?.src !== null
                    ) {
                        images.push(item.src);
                    }
                },
            );
        }

        if (!baseUrl) throw new Error("CDN Base URL not found");

        return { baseUrl, images };
    }

    #base64ToUtf8(base64String: string): string {
        return Buffer.from(base64String, "base64").toString("utf-8");
    }
}
