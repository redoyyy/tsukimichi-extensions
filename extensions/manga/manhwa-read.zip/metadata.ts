import type { ExtensionMetadata } from "@tsukimichi-extensions/common";

export const METADATA: ExtensionMetadata = {
    id: "3545ebde-b3db-4656-8eb5-c254c8fc942d",
    name: "ManhwaRead",
    description: "",
    isManga: true,
    containsNSFWContent: true,
    isNSFWFocused: true,
    minAppVersion: "1.0.0",
    url: "https://manhwaread.com",
    iconUrl:
        "https://t0.gstatic.com/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&url=https://manhwaread.com&size=128",
    version: "",
    apiUrl: "",
};
