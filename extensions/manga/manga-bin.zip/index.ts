import type {
    Filter,
    GetFilterConfig,
    MultiSelectFilter,
    NumberFilter,
    ScrapingOptions,
    SelectFilter,
    TextFilter,
} from "@tsukimichi-extensions/common";

import { Madara } from "@/lib/multi-src/madara";
import {
    MANGA_BIN_GENRES,
    MANGA_BIN_GENRES_CONDITION,
    MANGA_BIN_ORDER_BY_OPTIONS,
    MANGA_BIN_STATUS,
} from "./filters";

import manifest from "./manifest.json";

export class MangaBin extends Madara {
    override requireCoverImageProxy = false;

    constructor() {
        super(manifest);
    }

    protected override searchMangaRequest(
        query: string,
        options?: ScrapingOptions,
    ): Promise<Response> {
        const { page = 1, filters } = options?.searchOptions ?? {};
        const url = new URL(`/page/${page}`, this.baseUrl);
        url.searchParams.set("s", query);
        url.searchParams.set("post_type", "wp-manga");

        const config = this.getFilterConfig();
        const filterMap = new Map<string, Filter>(
            config.supportedFilters.map((f) => [f.key, f]),
        );

        for (const [key, value] of Object.entries(filters ?? {})) {
            const filter = filterMap.get(key);
            if (!filter || value === undefined || value === null) continue;

            switch (filter.type) {
                case "text":
                    if (typeof value === "string" && value.trim()) {
                        url.searchParams.set(key, value);
                    }
                    break;
                case "select":
                    // Using value for "op" other than 1 breaks the search
                    if (key === "op" && value !== 1) continue;
                    url.searchParams.set(key, value?.toString());
                    break;
                case "multi-select":
                    if (Array.isArray(value) && value.length) {
                        value.forEach((v) => {
                            url.searchParams.append(key, v?.toString());
                        });
                    }
                    break;
                case "number": {
                    const numFilter = filter as NumberFilter;
                    if (typeof value === "number" && !Number.isNaN(value)) {
                        const clampedValue = Math.max(
                            numFilter.min ?? Number.NEGATIVE_INFINITY,
                            Math.min(
                                numFilter.max ?? Number.POSITIVE_INFINITY,
                                value,
                            ),
                        );
                        url.searchParams.set(key, clampedValue.toString());
                    }
                    break;
                }
            }
        }

        const headers = {
            Referer: `${this.baseUrl}/`,
            Cookie: `wpmanga-adult=${filters?.includeNsfw ? "1" : "0"}`,
        };

        return fetch(url.toString(), {
            headers,
        });
    }

    override getFilterConfig: GetFilterConfig = (params) => {
        const includeNsfw = params?.includeNsfw ?? false;

        const filterNsfwOptions = (options: any[]) => {
            return options.map((option) => {
                return includeNsfw
                    ? option
                    : { ...option, disabled: option?.nsfw };
            });
        };

        return {
            extensionId: this.extensionMetadata.id,
            extensionName: this.name,
            supportedFilters: [
                {
                    key: "status[]",
                    label: "Select Status",
                    type: "multi-select",
                    multiple: true,
                    options: MANGA_BIN_STATUS,
                    renderAs: "select",
                } as MultiSelectFilter,
                {
                    key: "m_orderby",
                    label: "Order By",
                    type: "select",
                    multiple: false,
                    options: MANGA_BIN_ORDER_BY_OPTIONS,
                } as SelectFilter,
                {
                    key: "op",
                    label: "Genres Condition",
                    type: "select",
                    multiple: false,
                    options: MANGA_BIN_GENRES_CONDITION,
                } as SelectFilter,
                {
                    key: "author",
                    label: "Author",
                    type: "text",
                    placeholder: "Enter author name...",
                } as TextFilter,
                {
                    key: "artist",
                    label: "Artist",
                    type: "text",
                    placeholder: "Enter artist name...",
                } as TextFilter,
                {
                    key: "genre[]",
                    label: "Select Genres",
                    type: "multi-select",
                    multiple: true,
                    options: filterNsfwOptions(MANGA_BIN_GENRES),
                    renderAs: "checkbox-group",
                    description: "Multiple options can be selected",
                } as MultiSelectFilter,
            ],
        };
    };

    protected override searchSeriesSelector =
        ".c-tabs-item .row.c-tabs-item__content";
    protected override mangaSubString = "manga";
    protected override nextPageSelector = ".nav-links .nav-previous a";

    protected override seriesDetailsGenreSelector = "a[href*='/manga-genre/']";
    protected override seriesDetailsArtistSelector =
        "a[href*='/manga-artist/']";
    protected override seriesDetailsAuthorSelector =
        "a[href*='/manga-author/']";
    protected override seriesDetailsTagSelector = "a[href*='/manga-tag/']";
    protected override seriesDetailsDescriptionSelector =
        ".summary__content p.c_000";

    protected override alternateTitleDelimiter = ",";
}
