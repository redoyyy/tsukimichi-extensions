import type { FilterOption } from "@tsukimichi-extensions/common";

export const MANGA_BIN_STATUS: Array<FilterOption> = [
    { value: "on-going", label: "Ongoing" },
    { value: "end", label: "Completed" },
    { value: "canceled", label: "Cancelled" },
    { value: "on-hold", label: "Hiatus" },
    { value: "upcoming", label: "Upcoming" },
];

export const MANGA_BIN_GENRES = [
    { label: "Action", value: "action" },
    { label: "Adventure", value: "adventure" },
    { label: "Comedy", value: "comedy" },
    { label: "Drama", value: "drama" },
    { label: "Eastern", value: "eastern" },
    { label: "Fantasy", value: "fantasy" },
    { label: "Gender Bender", value: "genderbender" },
    { label: "Harem", value: "harem", nsfw: true },
    { label: "Historical", value: "historical" },
    { label: "Horror", value: "horror" },
    { label: "Josei", value: "josei" },
    { label: "Martial Arts", value: "martial-arts" },
    { label: "Mecha", value: "mecha" },
    { label: "Mystery", value: "mystery" },
    { label: "Psychological", value: "psychological" },
    { label: "Romance", value: "romance" },
    { label: "School Life", value: "school-life" },
    { label: "Sci-fi", value: "sci-fi" },
    { label: "Seinen", value: "seinen" },
    { label: "Shoujo", value: "shoujo" },
    { label: "Shounen", value: "shounen" },
    { label: "Slice of Life", value: "slice-of-life" },
    { label: "Smut", value: "smut" },
    { label: "Sports", value: "sports" },
    { label: "Supernatural", value: "supernatural" },
    { label: "Tragedy", value: "tragedy" },
    { label: "Xianxia", value: "xianxia" },
    { label: "Xuanhuan", value: "xuanhuan" },
    { label: "Yaoi", value: "yaoi", nsfw: true },
];

export const MANGA_BIN_GENRES_CONDITION: Array<FilterOption> = [
    {
        value: 0,
        label: "OR (Any Selected Genres)",
    },
    {
        value: 1,
        label: "AND (All Selected Genres)",
    },
];

export const MANGA_BIN_ORDER_BY_OPTIONS = [
    {
        label: "Relevance",
        vale: "relevance",
    },
    {
        label: "Latest",
        value: "latest",
    },
    {
        label: "Alphabetical(A-Z)",
        value: "alphabet",
    },
    {
        label: "Rating",
        value: "rating",
    },
    {
        label: "Trending",
        value: "trending",
    },
    {
        label: "Most Views",
        value: "views",
    },
    {
        label: "New Manga",
        value: "new-manga",
    },
];
