import type { ExtensionMetadata } from "@tsukimichi-extensions/common";

export const METADATA: ExtensionMetadata = {
    id: "a2c632c6-e3e5-45d5-a540-6354f774fc78",
    name: "Flame Comics",
    url: "https://flamecomics.xyz",
    isManga: true,
    containsNSFWContent: true,
    isNSFWFocused: false,
    minAppVersion: "1.0.0",
    iconUrl:
        "https://t0.gstatic.com/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&url=https://flamecomics.xyz/&size=128",
    description: "",
    version: "",
    apiUrl: "",
};
