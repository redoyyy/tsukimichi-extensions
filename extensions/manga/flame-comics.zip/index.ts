import type {
    Chapter,
    Filter,
    GetFilterConfig,
    GetLatestSeries,
    GetMangaChapterDetails,
    GetMangaChapters,
    GetPopularSeries,
    GetSeries,
    Manga,
    NumberFilter,
    ScrapingOptions,
    SearchSeries,
    SeriesListResponse,
} from "@tsukimichi-extensions/common";
import * as cheerio from "cheerio";

import { BaseMangaScraper } from "@/generic/base-manga-scraper";
import manifest from "./manifest.json";

export class FlameComics extends BaseMangaScraper {
    #cdnUrl = "https://cdn.flamecomics.xyz";
    #buildIdCacheTtl = 5 * 60 * 1000;
    #requestTimeout = 10000;
    override requireCoverImageProxy = false;

    #buildIdCache: { id: string; timestamp: number } | null = null;

    constructor() {
        super(manifest);
    }

    #headers = {
        "User-Agent":
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:135.0) Gecko/20100101 Firefox/135.0",
        "Accept-Language": "en-US,en;q=0.9",
        "Sec-Ch-Ua":
            '"Google Chrome";v="135", "Not(A:Brand";v="8", "Chromium";v="135"',
        Referer: this.baseUrl,
        "Cache-Control": "no-cache",
    };

    // TODO: add advanced search filters
    override searchSeries: SearchSeries<Manga> = async (query, options) => {
        const { page = 1, filters } = options?.searchOptions ?? {};

        const buildId = await this.#getBuildId();
        const url = new URL(this.#buildSearchUrl(buildId, query, page));
        const config = this.getFilterConfig();
        const filterMap = new Map<string, Filter>(
            config.supportedFilters.map((f) => [f.key, f]),
        );

        for (const [key, value] of Object.entries(filters ?? {})) {
            const filter = filterMap.get(key);
            if (!filter || value === undefined || value === null) continue;

            switch (filter.type) {
                case "text":
                    if (typeof value === "string" && value.trim()) {
                        url.searchParams.set(key, value);
                    }
                    break;
                case "select":
                    url.searchParams.set(key, value.toString());
                    break;
                case "multi-select":
                    if (Array.isArray(value) && value.length) {
                        value.forEach((v) =>
                            url.searchParams.append(key, v.toString()),
                        );
                    }
                    break;
                case "number": {
                    const numFilter = filter as NumberFilter;
                    const numValue = Number(value);
                    if (!Number.isNaN(numValue)) {
                        const clampedValue = Math.max(
                            numFilter.min || Number.NEGATIVE_INFINITY,
                            Math.min(
                                numFilter.max || Number.POSITIVE_INFINITY,
                                numValue,
                            ),
                        );
                        url.searchParams.set(key, clampedValue.toString());
                    }
                    break;
                }
            }
        }

        const response = await this.fetchWithRetry(url.toString());

        if (!response.ok) {
            console.error(`Search failed with status ${response.status}`, {
                query,
                page,
            });
            return { data: [] };
        }

        const result = await this.#parseSearchResult(response);

        if (filters?.includeNsfw) {
            return result;
        }

        return {
            data: result.data.filter((item) => !item.isNsfw),
            pagination: result.pagination,
        };
    };

    override getChapter: GetMangaChapterDetails = async (query) => {
        const buildId = await this.#getBuildId();
        const url = new URL(`_next/data/${buildId}${query}.json`, this.baseUrl);

        const response = await this.#fetchWithBuildIdRetry(url.toString());

        if (!response.ok) {
            console.error(
                `Chapter fetch failed: ${response.status} ${response.statusText}`,
                { query },
            );
            return null;
        }

        const json = await response.json();
        return await this.#parseChapterData(json);
    };

    override getChapters: GetMangaChapters = async (query) => {
        const buildId = await this.#getBuildId();
        const url = `${this.baseUrl}/_next/data/${buildId}${query}.json`;
        const response = await this.#fetchWithBuildIdRetry(url);

        if (!response.ok) {
            console.error(
                `Chapters fetch failed: ${response.status} ${response.statusText}`,
                { query },
            );
            return [];
        }

        const json = await response.json();
        if (!json?.pageProps?.chapters) return [];

        return this.#parseChapters(json.pageProps.chapters);
    };

    override getSeries: GetSeries<Manga> = async (query) => {
        const buildId = await this.#getBuildId();
        const url = this.#buildSeriesUrl(buildId, query);

        const response = await this.#fetchWithBuildIdRetry(url);

        if (!response.ok) {
            console.error(
                `Series fetch failed: ${response.status} ${response.statusText}`,
                { query },
            );
            return null;
        }

        const json = await response.json();

        if (!this.#isValidSeriesResponse(json)) {
            console.error("Invalid series response structure", { query });
            return null;
        }

        return this.#parseSeriesData(json, query);
    };

    override getLatestSeries: GetLatestSeries<Manga> = async (options) => {
        const { filters } = options?.searchOptions ?? {};
        const buildId = await this.#getBuildId();
        const url = `${this.baseUrl}/_next/data/${buildId}/index.json`;
        const response = await this.fetchWithRetry(url);

        if (!response.ok) {
            console.error(
                `Latest series fetch failed: ${response.status} ${response.statusText}`,
            );
            return { data: [] };
        }

        const json = await response.json();
        const result = await this.#processSeriesList(
            json,
            options?.searchOptions,
            "latest",
        );

        if (filters?.includeNsfw) {
            return result;
        }

        return {
            data: result.data.filter((item) => !item.isNsfw),
            pagination: result.pagination,
        };
    };

    override getPopularSeries: GetPopularSeries<Manga> = async (options) => {
        const { filters } = options?.searchOptions ?? {};
        const buildId = await this.#getBuildId();
        const url = `${this.baseUrl}/_next/data/${buildId}/index.json`;
        const response = await this.fetchWithRetry(url);

        if (!response.ok) {
            console.error(
                `Popular series fetch failed: ${response.status} ${response.statusText}`,
            );
            return { data: [] };
        }

        const json = await response.json();
        const result = await this.#processSeriesList(
            json,
            options?.searchOptions,
            "popular",
        );

        if (filters?.includeNsfw) {
            return result;
        }

        return {
            data: result.data.filter((item) => !item.isNsfw),
            pagination: result.pagination,
        };
    };

    // TODO: add filters
    override getFilterConfig: GetFilterConfig = () => {
        return {
            extensionId: this.extensionMetadata.id,
            extensionName: this.name,
            supportedFilters: [],
        };
    };

    // Helpers
    #isValidSeriesResponse(json: any): boolean {
        return Boolean(json?.pageProps?.series);
    }

    #buildSearchUrl(buildId: string, query: string, page: number): string {
        const url = new URL(`/_next/data/${buildId}/browse.json`, this.baseUrl);
        url.searchParams.set("q", this.#sanitizeQuery(query));
        url.searchParams.set("page", Math.max(1, page).toString());
        return url.toString();
    }

    #buildSeriesUrl(buildId: string, query: string): string {
        return `${this.baseUrl}/_next/data/${buildId}${query}.json`;
    }

    async #parseSearchResult(
        response: Response,
    ): Promise<SeriesListResponse<Manga>> {
        const json = await response.json();
        const searchParams = new URL(response.url).searchParams;
        const query = searchParams.get("q") || "";
        const page = Math.max(
            Number.parseInt(searchParams.get("page") || "1"),
            1,
        );
        const perPage = 20;

        const seriesList = json?.pageProps?.series || [];
        const filtered = this.#filterSeries(seriesList, query);
        // TODO: fix pagination
        const totalItems = filtered.length;
        const paginated = this.#paginateResults(filtered, page, perPage);

        const mapped = paginated.map((series) =>
            this.#mapSeriesListItem(series),
        );

        return {
            data: mapped,
            pagination: {
                hasMore: page * perPage < totalItems,
                nextPage: page * perPage < totalItems ? page + 1 : null,
            },
        };
    }

    async #processSeriesList(
        json: any,
        options: ScrapingOptions["searchOptions"],
        type: "popular" | "latest",
    ): Promise<SeriesListResponse<Manga>> {
        try {
            const { page = 1, limit = 20 } = options ?? {};

            const seriesPath =
                type === "popular"
                    ? json?.pageProps?.popularEntries?.blocks?.[0]?.series
                    : json?.pageProps?.latestEntries?.blocks?.[0]?.series;

            const seriesList = seriesPath || [];
            const mappedSeries = seriesList.map((series: any) =>
                this.#mapSeriesListItem(series),
            );
            const paginatedData = this.#paginateResults(
                mappedSeries,
                page,
                limit as number,
            );

            const totalItems = seriesList.length;

            return {
                data: paginatedData as unknown as SeriesListResponse<Manga>["data"],
                pagination: {
                    hasMore: page * (limit as number) < totalItems,
                    nextPage:
                        page * (limit as number) < totalItems ? page + 1 : null,
                },
            };
        } catch (error) {
            console.error(`Failed to process ${type} series list`, { error });
            return {
                data: [],
                pagination: { hasMore: false, nextPage: null },
            };
        }
    }

    #mapSeriesListItem(series: any): SeriesListResponse<Manga>["data"][number] {
        return {
            id: series.series_id,
            extensionId: this.extensionMetadata.id,
            title: series.title,
            status: this.getSeriesStatus(series.status),
            coverImageUrl: this.#buildCoverImageUrl(
                series.series_id,
                series.cover,
                series.last_edit,
            ),
            source: this.name,
            url: `/series/${series.series_id}`,
            isNsfw: this.detectNsfw(
                series.title,
                series.description,
                series.categories,
            ),
        };
    }

    #filterSeries(seriesList: any[], query: string): any[] {
        const normalizedQuery = this.#sanitizeQuery(query);

        return seriesList.filter((series) => {
            const title = this.#sanitizeQuery(series.title);
            const altTitles = this.#parseAltTitles(series.altTitles).map((t) =>
                this.#sanitizeQuery(t),
            );

            return (
                title.includes(normalizedQuery) ||
                altTitles.some((t) => t.includes(normalizedQuery))
            );
        });
    }

    #paginateResults<T>(items: T[], page: number, perPage: number): T[] {
        const startIndex = (page - 1) * perPage;
        return items.slice(startIndex, startIndex + perPage);
    }

    async #parseChapterData(json: any): Promise<Chapter | null> {
        try {
            const { chapter } = json?.pageProps || {};

            if (!chapter) {
                return null;
            }

            const images = this.#extractChapterImages(chapter);

            if (images.length === 0) {
                return null;
            }

            const chapters = await this.getChapters(
                `/series/${chapter?.series_id}`,
            );

            const matchedChapter = chapters?.find(
                (c) => c.id === chapter?.chapter_id?.toString(),
            );

            const nextChapter = matchedChapter
                ? matchedChapter?.nextChapter
                : null;
            const previousChapter = matchedChapter
                ? matchedChapter?.previousChapter
                : null;

            return {
                id: chapter.chapter_id?.toString(),
                extensionId: this.extensionMetadata.id,
                imageUrls: images,
                title: chapter?.chapter ? `Chapter ${chapter.chapter}` : "",
                url: `/series/${chapter?.series_id}/${chapter?.token}`,
                source: this.name,
                totalPages: images.length,
                nextChapter,
                previousChapter,
                languageKey: "en",
                chapterNumber: chapter?.chapter
                    ? Number.parseFloat(chapter.chapter)?.toString()
                    : null,
            };
        } catch (error) {
            console.error("Failed to parse chapter data", { error });
            return null;
        }
    }

    #parseSeriesData(json: any, query: string): Manga {
        const { series } = json.pageProps;

        return {
            id: series.series_id,
            extensionId: this.extensionMetadata.id,
            title: series.title,
            alternateTitles: this.#parseAltTitles(series.altTitles),
            description: series.description || "",
            genres: series.tags || [],
            authors: series.author,
            artists: series.artist,
            status: this.getSeriesStatus(series.status),
            coverImageUrl: this.#buildCoverImageUrl(
                series.series_id,
                series.cover,
                series.last_edit,
            ),
            isNsfw: this.detectNsfw(
                series.title,
                series.description,
                series.tags,
            ),
            source: this.name,
            url: `${query}`,
            isLocal: false,
        };
    }

    #parseChapters(chaptersList: any[]): Chapter[] {
        const chapters: Chapter[] = [];

        chaptersList?.forEach((chapter, i) => {
            const images = Object.values(chapter?.images || []);
            const url = `/series/${chapter.series_id}/${chapter.token}`;

            chapters.push({
                id: chapter.chapter_id?.toString(),
                extensionId: this.extensionMetadata.id,
                title: chapter?.chapter
                    ? `Chapter ${chapter.chapter}`
                    : `Chapter ${i + 1}`,
                url,
                imageUrls: images.map((image: any) =>
                    this.#buildChapterImageUrl(
                        chapter.series_id,
                        chapter.token,
                        image.name,
                    ),
                ),
                source: this.name,
                totalPages: images.length,
                nextChapter: null,
                languageKey: "en",
                previousChapter: null,
                chapterNumber: chapter.chapter,
            });
        });
        return this.addChapterNavigation(chapters?.reverse()) || [];
    }

    #extractChapterImages(chapter: any): string[] {
        return Object.values(chapter?.images || []).map((image: any) =>
            this.#buildChapterImageUrl(
                chapter.series_id,
                chapter.token,
                image.name,
            ),
        );
    }

    #formatChapterTitle(chapter: any): string {
        const baseTitle = `Chapter ${chapter.chapter}`;
        return chapter.title ? `${baseTitle} - ${chapter.title}` : baseTitle;
    }

    #parseAltTitles(altTitles: string): string[] {
        try {
            const parsed = JSON.parse(altTitles || "[]");
            return Array.isArray(parsed) ? parsed.filter(Boolean) : [];
        } catch {
            return [];
        }
    }

    #buildCoverImageUrl(id: string, cover: string, lastEdit: string): string {
        if (!id || !cover) {
            return "";
        }

        const base = new URL("_next/image", this.baseUrl);

        const imageUrl = `${this.#cdnUrl}/uploads/images/series/${id}/${cover}?/${lastEdit}`;

        base.searchParams.set("url", imageUrl);
        base.searchParams.set("w", "384");
        base.searchParams.set("q", "75");

        return base.toString();
    }

    #buildChapterImageUrl(
        seriesId: string,
        token: string,
        imageName: string,
    ): string {
        const imageUrl = new URL(
            `uploads/images/series/${seriesId}/${token}/${imageName}`,
            this.#cdnUrl,
        );
        return imageUrl.toString();
    }

    async #fetchBuildId(html?: string): Promise<string> {
        const content = html || (await this.fetchHtml(this.baseUrl));
        const $ = cheerio.load(content);
        const scriptContent = $("script#__NEXT_DATA__").text();

        if (!scriptContent) {
            throw new Error("__NEXT_DATA__ script not found");
        }

        const json = JSON.parse(scriptContent);
        const buildId = json.buildId;

        if (!buildId) {
            throw new Error("Build ID not found in __NEXT_DATA__");
        }

        return buildId;
    }

    async #getBuildId(): Promise<string> {
        if (this.#buildIdCache) {
            const isExpired =
                Date.now() - this.#buildIdCache.timestamp >
                this.#buildIdCacheTtl;
            if (!isExpired) {
                return this.#buildIdCache.id;
            }
        }

        const buildId = await this.#fetchBuildId();
        this.#buildIdCache = {
            id: buildId,
            timestamp: Date.now(),
        };

        return buildId;
    }

    #sanitizeQuery(input: string): string {
        return input
            .toLowerCase()
            .replace(/[^a-z0-9 ]/g, "")
            .trim();
    }

    async #fetchWithBuildIdRetry(
        url: string,
        retryCount = 0,
    ): Promise<Response> {
        const response = await this.fetchWithRetry(url, retryCount);

        if (this.#shouldRetryWithNewBuildId(response, url)) {
            return this.#handleBuildIdRetry(response, url);
        }

        return response;
    }

    #shouldRetryWithNewBuildId(response: Response, url: string): boolean {
        const urlObj = new URL(url);
        return !!(
            !response.ok &&
            urlObj.hostname === new URL(this.baseUrl).hostname &&
            urlObj.pathname.startsWith("/_next/data/") &&
            !urlObj.hash.includes("DO_NOT_RETRY") &&
            response.headers.get("content-type")?.includes("text/html")
        );
    }

    async #handleBuildIdRetry(
        response: Response,
        originalUrl: string,
    ): Promise<Response> {
        try {
            const html = await response.text();
            const newBuildId = await this.#fetchBuildId(html);

            // Update cache with new build ID
            this.#buildIdCache = {
                id: newBuildId,
                timestamp: Date.now(),
            };

            const url = new URL(originalUrl);
            const segments = url.pathname.split("/");
            segments[3] = newBuildId;
            url.pathname = segments.join("/");
            url.hash = "#DO_NOT_RETRY";

            return fetch(url.toString(), {
                headers: this.#headers,
                signal: AbortSignal.timeout(this.#requestTimeout),
            });
        } catch (error) {
            console.error("Build ID retry failed", { originalUrl, error });
            throw new Error("Failed to retry with new build ID");
        }
    }
}

// const client = new FlameComics();

// client.getChapters("/series/127").then((d) => {
//     console.log(d.slice(0, 4));
// });
