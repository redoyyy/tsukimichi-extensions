import type {
    Filter,
    FilterValues,
    GetFilterConfig,
    MultiSelectFilter,
    NumberFilter,
    ScrapingOptions,
    SelectFilter,
    TextFilter,
} from "@tsukimichi-extensions/common";

import { Madara } from "@/lib/multi-src/madara";
import {
    TOONILY_ADULT_CONTENT_FILTER,
    TOONILY_GENRES,
    TOONILY_GENRES_CONDITION,
    TOONILY_ORDER_BY_OPTIONS,
    TOONILY_STATUS,
} from "./filters";
import manifest from "./manifest.json";

export class Toonily extends Madara {
    override requireCoverImageProxy = true;
    override requireChapterImageProxy = true;

    constructor() {
        super(manifest);
    }

    override getFilterConfig: GetFilterConfig = (params) => {
        const includeNsfw = params?.includeNsfw ?? false;

        const toonilyAdultContentFilter = TOONILY_ADULT_CONTENT_FILTER.map(
            (option) => {
                const isNsfw = option.value === "all" || option.value === "1";
                return includeNsfw ? option : { ...option, disabled: isNsfw };
            },
        );

        return {
            extensionId: this.extensionMetadata.id,
            extensionName: this.name,
            supportedFilters: [
                {
                    key: "genre",
                    label: "Select Genres",
                    type: "multi-select",
                    multiple: true,
                    options: TOONILY_GENRES,
                    renderAs: "checkbox-group",
                } as MultiSelectFilter,
                {
                    key: "status",
                    label: "Select Status",
                    type: "multi-select",
                    multiple: true,
                    options: TOONILY_STATUS,
                    renderAs: "checkbox-group",
                } as MultiSelectFilter,
                {
                    key: "op",
                    label: "Genres Condition",
                    type: "select",
                    multiple: false,
                    options: TOONILY_GENRES_CONDITION,
                } as SelectFilter,
                {
                    key: "adult",
                    label: "Content Shown",
                    type: "select",
                    multiple: false,
                    options: toonilyAdultContentFilter,
                } as SelectFilter,
                {
                    key: "m_orderby",
                    label: "Order By",
                    type: "select",
                    multiple: false,
                    options: TOONILY_ORDER_BY_OPTIONS,
                } as SelectFilter,
                {
                    key: "author",
                    label: "Author",
                    type: "text",
                    placeholder: "Enter author name...",
                } as TextFilter,
                {
                    key: "artist",
                    label: "Artist",
                    type: "text",
                    placeholder: "Enter artist name...",
                } as TextFilter,
                // We don't add `includeNsfw` here as it will
                // be passed directly from user settings
                // instead of the filter config
            ],
        };
    };

    protected override async searchMangaRequest(
        query: string,
        options?: ScrapingOptions,
    ): Promise<Response> {
        const { page = 1, filters } = options?.searchOptions ?? {};
        const url = new URL(`page/${page}`, this.baseUrl);
        url.searchParams.set("s", query);
        url.searchParams.set("post_type", "wp-manga");

        const config = this.getFilterConfig();
        const filterMap = new Map<string, Filter>(
            config.supportedFilters.map((f) => [f.key, f]),
        );

        for (const [key, value] of Object.entries(filters ?? {})) {
            const filter = filterMap.get(key);
            if (!filter || value === undefined || value === null) continue;

            switch (filter.type) {
                case "text":
                    if (typeof value === "string" && value.trim()) {
                        url.searchParams.set(key, value);
                    }
                    break;
                case "select":
                    // Using value for "op" other than 1 breaks the search
                    if (key === "op" && value !== 1) continue;
                    url.searchParams.set(key, value?.toString());
                    if (value !== "all" || value !== "any")
                        url.searchParams.set(key, value?.toString());
                    break;
                case "multi-select":
                    if (Array.isArray(value) && value.length) {
                        value.forEach((v, i) => {
                            url.searchParams.append(
                                `${key}[${i}]`,
                                v?.toString(),
                            );
                        });
                    }
                    break;
                case "number": {
                    const numFilter = filter as NumberFilter;
                    if (typeof value === "number" && !Number.isNaN(value)) {
                        const clampedValue = Math.max(
                            numFilter.min ?? Number.NEGATIVE_INFINITY,
                            Math.min(
                                numFilter.max ?? Number.POSITIVE_INFINITY,
                                value,
                            ),
                        );
                        url.searchParams.set(key, clampedValue.toString());
                    }
                    break;
                }
            }
        }

        return await fetch(url.toString(), {
            ...options?.init,
            headers: this.getMatureContentHeaders(options?.searchOptions),
        });
    }

    protected override async popularMangaRequest(options?: ScrapingOptions) {
        const { page = 1 } = options?.searchOptions ?? {};
        const url = new URL(`webtoons/page/${page}`, this.baseUrl);
        url.searchParams.set("m_orderby", "views");

        return fetch(url.toString(), {
            ...options?.init,
            headers: this.getMatureContentHeaders(options?.searchOptions),
        });
    }

    protected override async latestMangaRequest(options?: ScrapingOptions) {
        const { page = 1 } = options?.searchOptions ?? {};
        const url = new URL(`webtoons/page/${page}`, this.baseUrl);
        url.searchParams.set("m_orderby", "latest");

        return fetch(url.toString(), {
            ...options?.init,
            headers: this.getMatureContentHeaders(options?.searchOptions),
        });
    }

    protected getMatureContentHeaders(options?: FilterValues) {
        return {
            Cookie: `toonily-mature=${options?.filters?.includeNsfw ? "1" : "0"}`,
        };
    }

    protected override currentPageSelector = ".wp-pagenavi span.current";
    protected override nextPageSelector = '.wp-pagenavi a[rel="next"]';
    protected override searchSeriesSelector =
        ".page-listing-item .page-item-detail";
    protected override mangaSubString = "serie";

    protected override alternateTitleDelimiter = ",";
}
